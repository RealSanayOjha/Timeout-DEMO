import { useState } from "react";
import { Play, Users, BookOpen, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { FocusTimer } from "@/components/FocusTimer";
import { WellnessDashboard } from "@/components/WellnessDashboard";
import { StudyRoomCard } from "@/components/StudyRoomCard";
import heroWellness from "@/assets/hero-wellness.jpg";
import wellnessPattern from "@/assets/wellness-pattern.jpg";

interface QuickAction {
  title: string;
  description: string;
  icon: React.ElementType;
  color: string;
  action: () => void;
}

export default function Dashboard() {
  const [showTimer, setShowTimer] = useState(false);

  const quickActions: QuickAction[] = [
    {
      title: "Start Focus Session",
      description: "Begin a focused study session",
      icon: Play,
      color: "primary",
      action: () => setShowTimer(true),
    },
    {
      title: "Join Study Room",
      description: "Connect with study groups",
      icon: Users,
      color: "secondary",
      action: () => console.log("Join study room"),
    },
    {
      title: "My Classes",
      description: "Access your scheduled classes",
      icon: BookOpen,
      color: "accent",
      action: () => console.log("My classes"),
    },
  ];

  const activeStudyRooms = [
    {
      id: "1",
      title: "JEE Mathematics - Calculus Focus",
      subject: "Mathematics",
      participants: 8,
      maxParticipants: 12,
      timeRemaining: "2h 15m",
      difficulty: "Intermediate" as const,
      isActive: true,
      tags: ["JEE", "Calculus", "Problem Solving"],
      hostName: "Priya Sharma",
    },
    {
      id: "2", 
      title: "NEET Biology Study Group",
      subject: "Biology",
      participants: 15,
      maxParticipants: 15,
      timeRemaining: "45m",
      difficulty: "Advanced" as const,
      isActive: true,
      tags: ["NEET", "Biology", "Group Study"],
      hostName: "Arjun Patel",
    },
    {
      id: "3",
      title: "English Literature Discussion",
      subject: "English",
      participants: 6,
      maxParticipants: 10,
      timeRemaining: "1h 30m",
      difficulty: "Beginner" as const,
      isActive: true,
      tags: ["Literature", "Discussion", "Analysis"],
      hostName: "Maya Singh",
    },
  ];

  const handleJoinRoom = (roomId: string) => {
    console.log(`Joining room: ${roomId}`);
    // Implement join room logic
  };

  const handleViewRoom = (roomId: string) => {
    console.log(`Viewing room: ${roomId}`);
    // Implement view room logic
  };

  const handleSessionComplete = () => {
    console.log("Focus session completed!");
    setShowTimer(false);
  };

  if (showTimer) {
    return (
      <div className="min-h-screen bg-gradient-wellness p-6">
        <div className="max-w-4xl mx-auto">
          <div className="mb-6">
            <Button
              variant="outline"
              onClick={() => setShowTimer(false)}
              className="mb-4"
            >
              ← Back to Dashboard
            </Button>
          </div>
          <FocusTimer onSessionComplete={handleSessionComplete} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-wellness">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-10"
          style={{ backgroundImage: `url(${heroWellness})` }}
        />
        <div className="relative px-6 py-12">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-display font-bold text-foreground mb-4">
                Welcome to TimeOut
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
                Your digital wellness companion for focused learning and community growth.
                Take control of your study habits and connect with fellow learners.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                  🎯 Digital Wellness
                </Badge>
                <Badge variant="outline" className="bg-secondary/10 text-secondary border-secondary/20">
                  👥 Community Learning
                </Badge>
                <Badge variant="outline" className="bg-accent/10 text-accent border-accent/20">
                  📚 Smart Study Tools
                </Badge>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="grid md:grid-cols-3 gap-6 mb-12">
              {quickActions.map((action, index) => (
                <Card
                  key={index}
                  className="cursor-pointer transition-all duration-300 hover:shadow-focus hover:-translate-y-1 shadow-soft"
                  onClick={action.action}
                >
                  <CardContent className="p-6 text-center">
                    <div className={`w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-${action.color} flex items-center justify-center shadow-wellness`}>
                      <action.icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-lg font-display font-semibold text-card-foreground mb-2">
                      {action.title}
                    </h3>
                    <p className="text-muted-foreground text-sm">
                      {action.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-6 pb-12">
        <div className="max-w-6xl mx-auto space-y-12">
          {/* Active Study Rooms */}
          <section>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-display font-bold text-foreground">
                  Active Study Rooms
                </h2>
                <p className="text-muted-foreground mt-1">
                  Join live study sessions with your peers
                </p>
              </div>
              <Button
                variant="outline"
                className="border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-smooth"
              >
                View All Rooms
              </Button>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {activeStudyRooms.map((room) => (
                <StudyRoomCard
                  key={room.id}
                  {...room}
                  onJoin={handleJoinRoom}
                  onView={handleViewRoom}
                />
              ))}
            </div>
          </section>

          {/* Wellness Dashboard Preview */}
          <section>
            <div className="mb-6">
              <h2 className="text-2xl font-display font-bold text-foreground mb-2">
                Your Wellness Journey
              </h2>
              <p className="text-muted-foreground">
                Track your progress and build healthy digital habits
              </p>
            </div>

            <div className="grid md:grid-cols-4 gap-6 mb-8">
              <Card className="shadow-soft">
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-primary mb-1">7</div>
                  <div className="text-sm text-muted-foreground">Day Streak</div>
                </CardContent>
              </Card>
              <Card className="shadow-soft">
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-secondary mb-1">24h</div>
                  <div className="text-sm text-muted-foreground">Focus Time</div>
                </CardContent>
              </Card>
              <Card className="shadow-soft">
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-success mb-1">-23%</div>
                  <div className="text-sm text-muted-foreground">Screen Time</div>
                </CardContent>
              </Card>
              <Card className="shadow-soft">
                <CardContent className="p-6 text-center">
                  <div className="text-3xl font-bold text-accent mb-1">12</div>
                  <div className="text-sm text-muted-foreground">Sessions</div>
                </CardContent>
              </Card>
            </div>

            <div className="text-center">
              <Button
                className="bg-gradient-focus text-accent-foreground shadow-wellness transition-smooth hover:opacity-90"
              >
                <TrendingUp className="w-4 h-4 mr-2" />
                View Full Analytics
              </Button>
            </div>
          </section>

          {/* Motivational Quote */}
          <Card className="shadow-soft bg-gradient-to-r from-primary/5 to-secondary/5 border-primary/20">
            <CardContent className="p-8 text-center">
              <blockquote className="text-lg italic text-foreground mb-4">
                "The successful warrior is the average person with laser-like focus."
              </blockquote>
              <cite className="text-sm text-muted-foreground">— Bruce Lee</cite>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}