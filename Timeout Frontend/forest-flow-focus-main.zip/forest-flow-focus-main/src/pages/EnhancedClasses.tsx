import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ClassesTab } from "@/components/ClassesTab";
import { ScheduleMaker } from "@/components/ScheduleMaker";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BookOpen, Calendar, Video, Users } from "lucide-react";

export default function EnhancedClasses() {
  return (
    <div className="min-h-screen bg-gradient-wellness p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-display font-bold text-foreground mb-2">
            Advanced Classroom
          </h1>
          <p className="text-muted-foreground">
            Enhanced learning experience with live classes, scheduling, and institutional tools
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center mb-3">
                <Video className="w-8 h-8 text-primary" />
              </div>
              <div className="text-2xl font-bold text-primary mb-1">3</div>
              <div className="text-sm text-muted-foreground">Live Classes</div>
            </CardContent>
          </Card>

          <Card className="shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center mb-3">
                <Calendar className="w-8 h-8 text-secondary" />
              </div>
              <div className="text-2xl font-bold text-secondary mb-1">12</div>
              <div className="text-sm text-muted-foreground">Scheduled Classes</div>
            </CardContent>
          </Card>

          <Card className="shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center mb-3">
                <Users className="w-8 h-8 text-accent" />
              </div>
              <div className="text-2xl font-bold text-accent mb-1">45</div>
              <div className="text-sm text-muted-foreground">Students Online</div>
            </CardContent>
          </Card>

          <Card className="shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center mb-3">
                <BookOpen className="w-8 h-8 text-success" />
              </div>
              <div className="text-2xl font-bold text-success mb-1">8</div>
              <div className="text-sm text-muted-foreground">Subjects</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="classes" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="classes" className="flex items-center gap-2">
              <Video className="w-4 h-4" />
              Live Classes
            </TabsTrigger>
            <TabsTrigger value="schedule" className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Schedule Maker
            </TabsTrigger>
          </TabsList>

          <TabsContent value="classes">
            <ClassesTab />
          </TabsContent>

          <TabsContent value="schedule">
            <ScheduleMaker />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}