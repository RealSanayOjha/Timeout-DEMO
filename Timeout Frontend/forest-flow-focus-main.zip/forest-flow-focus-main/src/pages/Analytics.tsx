import { WellnessDashboard } from "@/components/WellnessDashboard";

export default function Analytics() {
  return (
    <div className="min-h-screen bg-gradient-wellness p-6">
      <div className="max-w-6xl mx-auto">
        <WellnessDashboard />
      </div>
    </div>
  );
}