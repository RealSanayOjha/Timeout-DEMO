import { Calendar, BookOpen, Video, Users, Clock, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const upcomingClasses = [
  {
    id: "1",
    title: "Advanced Mathematics - Calculus",
    instructor: "Dr. Priya Sharma", 
    time: "10:00 AM - 11:30 AM",
    date: "Today",
    participants: 24,
    maxParticipants: 30,
    status: "upcoming",
    subject: "Mathematics",
  },
  {
    id: "2",
    title: "Physics - Quantum Mechanics",
    instructor: "Prof. Rajesh Kumar",
    time: "2:00 PM - 3:30 PM", 
    date: "Today",
    participants: 18,
    maxParticipants: 25,
    status: "upcoming",
    subject: "Physics",
  },
  {
    id: "3",
    title: "Chemistry - Organic Compounds",
    instructor: "Dr. Ananya Reddy",
    time: "11:00 AM - 12:30 PM",
    date: "Tomorrow",
    participants: 22,
    maxParticipants: 30,
    status: "scheduled",
    subject: "Chemistry",
  },
];

export default function Classes() {
  return (
    <div className="min-h-screen bg-gradient-wellness p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-display font-bold text-foreground mb-2">
                My Classes
              </h1>
              <p className="text-muted-foreground">
                Join virtual classrooms and manage your academic schedule
              </p>
            </div>
            <Button className="bg-gradient-secondary text-secondary-foreground shadow-wellness transition-smooth hover:opacity-90">
              <Plus className="w-4 h-4 mr-2" />
              Schedule Class
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="shadow-soft">
            <CardContent className="p-6 text-center">
              <Calendar className="w-8 h-8 text-primary mx-auto mb-3" />
              <div className="text-2xl font-bold text-primary mb-1">12</div>
              <div className="text-sm text-muted-foreground">This Week</div>
            </CardContent>
          </Card>

          <Card className="shadow-soft">
            <CardContent className="p-6 text-center">
              <Video className="w-8 h-8 text-secondary mx-auto mb-3" />
              <div className="text-2xl font-bold text-secondary mb-1">3</div>
              <div className="text-sm text-muted-foreground">Live Now</div>
            </CardContent>
          </Card>

          <Card className="shadow-soft">
            <CardContent className="p-6 text-center">
              <Users className="w-8 h-8 text-accent mx-auto mb-3" />
              <div className="text-2xl font-bold text-accent mb-1">145</div>
              <div className="text-sm text-muted-foreground">Classmates</div>
            </CardContent>
          </Card>

          <Card className="shadow-soft">
            <CardContent className="p-6 text-center">
              <BookOpen className="w-8 h-8 text-success mx-auto mb-3" />
              <div className="text-2xl font-bold text-success mb-1">8</div>
              <div className="text-sm text-muted-foreground">Subjects</div>
            </CardContent>
          </Card>
        </div>

        {/* Upcoming Classes */}
        <div className="mb-8">
          <h2 className="text-2xl font-display font-bold text-foreground mb-6">
            Upcoming Classes
          </h2>

          <div className="space-y-4">
            {upcomingClasses.map((classItem) => (
              <Card key={classItem.id} className="shadow-soft hover:shadow-wellness transition-smooth">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-4 mb-2">
                        <h3 className="text-lg font-display font-semibold text-card-foreground">
                          {classItem.title}
                        </h3>
                        <Badge
                          className={`text-xs ${
                            classItem.status === "upcoming"
                              ? "bg-primary text-primary-foreground"
                              : "bg-muted text-muted-foreground"
                          }`}
                        >
                          {classItem.status === "upcoming" ? "Starting Soon" : "Scheduled"}
                        </Badge>
                      </div>

                      <div className="flex items-center gap-6 text-sm text-muted-foreground mb-3">
                        <div className="flex items-center gap-1">
                          <Users className="w-4 h-4" />
                          <span>{classItem.instructor}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          <span>{classItem.time}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          <span>{classItem.date}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <Badge variant="outline" className="bg-accent/10 text-accent border-accent/20">
                          {classItem.subject}
                        </Badge>
                        <span className="text-sm text-muted-foreground">
                          {classItem.participants}/{classItem.maxParticipants} students
                        </span>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        className="border-accent text-accent hover:bg-accent hover:text-accent-foreground transition-smooth"
                      >
                        View Details
                      </Button>
                      {classItem.status === "upcoming" && (
                        <Button className="bg-gradient-primary text-primary-foreground shadow-focus transition-smooth">
                          <Video className="w-4 h-4 mr-2" />
                          Join Class
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="shadow-soft">
            <CardHeader>
              <CardTitle className="font-display">Create Virtual Classroom</CardTitle>
              <CardDescription>
                Start an instant video session for teaching or group study
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button className="w-full bg-gradient-secondary text-secondary-foreground shadow-wellness transition-smooth">
                <Video className="w-4 h-4 mr-2" />
                Start Video Session
              </Button>
            </CardContent>
          </Card>

          <Card className="shadow-soft">
            <CardHeader>
              <CardTitle className="font-display">Schedule New Class</CardTitle>
              <CardDescription>
                Plan and schedule recurring or one-time classes
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                variant="outline" 
                className="w-full border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-smooth"
              >
                <Calendar className="w-4 h-4 mr-2" />
                Open Scheduler
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}