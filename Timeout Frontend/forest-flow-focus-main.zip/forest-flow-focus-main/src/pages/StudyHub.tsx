import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StudyTab } from "@/components/StudyTab";
import { EnhancedGroupsTab } from "@/components/EnhancedGroupsTab";
import { DigitalDetoxTab } from "@/components/DigitalDetoxTab";
import { Card, CardContent } from "@/components/ui/card";
import { Timer, Users, Shield, Trophy } from "lucide-react";

export default function StudyHub() {
  return (
    <div className="min-h-screen bg-gradient-wellness p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-display font-bold text-foreground mb-2">
            Study Hub
          </h1>
          <p className="text-muted-foreground">
            Advanced study tools with photo verification, leaderboards, and digital wellness
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center mb-3">
                <Timer className="w-8 h-8 text-primary" />
              </div>
              <div className="text-2xl font-bold text-primary mb-1">2h 45m</div>
              <div className="text-sm text-muted-foreground">Focus Time Today</div>
            </CardContent>
          </Card>

          <Card className="shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center mb-3">
                <Users className="w-8 h-8 text-secondary" />
              </div>
              <div className="text-2xl font-bold text-secondary mb-1">8</div>
              <div className="text-sm text-muted-foreground">Active Groups</div>
            </CardContent>
          </Card>

          <Card className="shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center mb-3">
                <Shield className="w-8 h-8 text-accent" />
              </div>
              <div className="text-2xl font-bold text-accent mb-1">12</div>
              <div className="text-sm text-muted-foreground">Check-ins Verified</div>
            </CardContent>
          </Card>

          <Card className="shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center mb-3">
                <Trophy className="w-8 h-8 text-success" />
              </div>
              <div className="text-2xl font-bold text-success mb-1">#3</div>
              <div className="text-sm text-muted-foreground">Leaderboard Rank</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="study" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="study" className="flex items-center gap-2">
              <Timer className="w-4 h-4" />
              Focus Timer
            </TabsTrigger>
            <TabsTrigger value="groups" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              Study Groups
            </TabsTrigger>
            <TabsTrigger value="wellness" className="flex items-center gap-2">
              <Shield className="w-4 h-4" />
              Digital Wellness
            </TabsTrigger>
          </TabsList>

          <TabsContent value="study">
            <StudyTab />
          </TabsContent>

          <TabsContent value="groups">
            <EnhancedGroupsTab />
          </TabsContent>

          <TabsContent value="wellness">
            <DigitalDetoxTab />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}