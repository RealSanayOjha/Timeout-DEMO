import { FocusTimer } from "@/components/FocusTimer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Brain, Target, Clock, TrendingUp, Zap, Users } from "lucide-react";

export default function FocusPage() {
  const handleSessionComplete = () => {
    console.log("Focus session completed!");
    // Implement session completion logic (notifications, streak updates, etc.)
  };

  const focusTips = [
    {
      icon: Brain,
      title: "Deep Work Mode",
      description: "Turn off notifications and focus on a single task",
      color: "primary",
    },
    {
      icon: Target,
      title: "Set Clear Goals",
      description: "Define what you want to achieve in this session",
      color: "secondary",
    },
    {
      icon: Clock,
      title: "Take Breaks",
      description: "Short breaks help maintain focus and productivity",
      color: "accent",
    },
    {
      icon: TrendingUp,
      title: "Track Progress",
      description: "Monitor your focus patterns and improve over time",
      color: "success",
    },
  ];

  const sessionHistory = [
    { date: "Today", sessions: 3, totalTime: "2h 15m", streak: true },
    { date: "Yesterday", sessions: 4, totalTime: "3h 30m", streak: true },
    { date: "2 days ago", sessions: 2, totalTime: "1h 45m", streak: true },
    { date: "3 days ago", sessions: 5, totalTime: "4h 20m", streak: true },
  ];

  return (
    <div className="min-h-screen bg-gradient-wellness p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-display font-bold text-foreground mb-4">
            Focus Timer
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-6">
            Build concentration and productivity with focused study sessions.
            Choose your session type and dive deep into focused learning.
          </p>
          <div className="flex justify-center gap-2">
            <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
              🎯 Deep Focus
            </Badge>
            <Badge variant="outline" className="bg-secondary/10 text-secondary border-secondary/20">
              🍅 Pomodoro
            </Badge>
            <Badge variant="outline" className="bg-accent/10 text-accent border-accent/20">
              📚 Study Sessions
            </Badge>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Timer */}
          <div className="lg:col-span-2">
            <FocusTimer onSessionComplete={handleSessionComplete} />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Today's Progress */}
            <Card className="shadow-soft">
              <CardHeader>
                <CardTitle className="text-lg font-display flex items-center">
                  <Zap className="w-5 h-5 mr-2 text-primary" />
                  Today's Progress
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Sessions</span>
                  <span className="font-semibold text-primary">3</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Focus Time</span>
                  <span className="font-semibold text-secondary">2h 15m</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Streak</span>
                  <Badge className="bg-success text-success-foreground">
                    7 days 🔥
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Focus Tips */}
            <Card className="shadow-soft">
              <CardHeader>
                <CardTitle className="text-lg font-display">Focus Tips</CardTitle>
                <CardDescription>
                  Maximize your concentration and productivity
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {focusTips.map((tip, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className={`w-8 h-8 rounded-full bg-${tip.color}/10 flex items-center justify-center flex-shrink-0`}>
                      <tip.icon className={`w-4 h-4 text-${tip.color}`} />
                    </div>
                    <div>
                      <h4 className="font-medium text-sm text-card-foreground">
                        {tip.title}
                      </h4>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        {tip.description}
                      </p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="shadow-soft">
              <CardHeader>
                <CardTitle className="text-lg font-display">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full justify-start bg-gradient-secondary text-secondary-foreground shadow-wellness">
                  <Users className="w-4 h-4 mr-2" />
                  Join Study Room
                </Button>
                <Button variant="outline" className="w-full justify-start border-accent text-accent hover:bg-accent hover:text-accent-foreground">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  View Analytics
                </Button>
                <Button variant="outline" className="w-full justify-start border-primary text-primary hover:bg-primary hover:text-primary-foreground">
                  <Target className="w-4 h-4 mr-2" />
                  Set Daily Goal
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Session History */}
        <div className="mt-12">
          <h2 className="text-2xl font-display font-bold text-foreground mb-6">
            Recent Sessions
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {sessionHistory.map((day, index) => (
              <Card key={index} className="shadow-soft">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-card-foreground">
                      {day.date}
                    </span>
                    {day.streak && (
                      <Badge variant="outline" className="text-xs bg-success/10 text-success border-success/20">
                        ✓
                      </Badge>
                    )}
                  </div>
                  <div className="space-y-1">
                    <div className="text-xs text-muted-foreground">
                      {day.sessions} sessions
                    </div>
                    <div className="text-lg font-bold text-primary">
                      {day.totalTime}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Breathing Exercise */}
        <Card className="mt-8 shadow-soft bg-gradient-to-r from-accent/5 to-primary/5 border-accent/20">
          <CardContent className="p-8 text-center">
            <h3 className="text-xl font-display font-semibold text-foreground mb-4">
              Take a Mindful Break
            </h3>
            <p className="text-muted-foreground mb-6">
              Between focus sessions, try a quick breathing exercise to reset your mind.
            </p>
            <Button
              variant="outline"
              className="border-accent text-accent hover:bg-accent hover:text-accent-foreground transition-smooth"
            >
              Start Breathing Exercise
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}