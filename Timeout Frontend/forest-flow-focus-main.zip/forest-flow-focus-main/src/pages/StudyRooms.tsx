import { useState } from "react";
import { Plus, Search, Filter, Users, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { StudyRoomCard } from "@/components/StudyRoomCard";

const mockStudyRooms = [
  {
    id: "1",
    title: "JEE Mathematics - Calculus Focus",
    subject: "Mathematics",
    participants: 8,
    maxParticipants: 12,
    timeRemaining: "2h 15m",
    difficulty: "Intermediate" as const,
    isActive: true,
    tags: ["JEE", "Calculus", "Problem Solving"],
    hostName: "Priya Sharma",
  },
  {
    id: "2",
    title: "NEET Biology Study Group",
    subject: "Biology", 
    participants: 15,
    maxParticipants: 15,
    timeRemaining: "45m",
    difficulty: "Advanced" as const,
    isActive: true,
    tags: ["NEET", "Biology", "Group Study"],
    hostName: "Arjun Patel",
  },
  {
    id: "3",
    title: "English Literature Discussion",
    subject: "English",
    participants: 6,
    maxParticipants: 10,
    timeRemaining: "1h 30m",
    difficulty: "Beginner" as const,
    isActive: true,
    tags: ["Literature", "Discussion", "Analysis"],
    hostName: "Maya Singh",
  },
  {
    id: "4",
    title: "Physics Problem Solving",
    subject: "Physics",
    participants: 4,
    maxParticipants: 8,
    timeRemaining: "3h",
    difficulty: "Advanced" as const,
    isActive: false,
    tags: ["Physics", "Problems", "JEE"],
    hostName: "Rajesh Kumar",
  },
  {
    id: "5",
    title: "Chemistry Organic Compounds",
    subject: "Chemistry",
    participants: 10,
    maxParticipants: 12,
    timeRemaining: "1h 45m",
    difficulty: "Intermediate" as const,
    isActive: true,
    tags: ["Chemistry", "Organic", "NEET"],
    hostName: "Ananya Reddy",
  },
  {
    id: "6",
    title: "Computer Science Algorithms",
    subject: "Computer Science",
    participants: 7,
    maxParticipants: 10,
    timeRemaining: "2h 30m",
    difficulty: "Advanced" as const,
    isActive: true,
    tags: ["CS", "Algorithms", "Programming"],
    hostName: "Vikram Singh",
  },
];

export default function StudyRooms() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("all");
  const [selectedDifficulty, setSelectedDifficulty] = useState("all");
  const [showOnlyActive, setShowOnlyActive] = useState(false);

  const subjects = ["all", "Mathematics", "Physics", "Chemistry", "Biology", "English", "Computer Science"];
  const difficulties = ["all", "Beginner", "Intermediate", "Advanced"];

  const filteredRooms = mockStudyRooms.filter((room) => {
    const matchesSearch = room.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         room.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         room.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesSubject = selectedSubject === "all" || room.subject === selectedSubject;
    const matchesDifficulty = selectedDifficulty === "all" || room.difficulty === selectedDifficulty;
    const matchesActive = !showOnlyActive || room.isActive;

    return matchesSearch && matchesSubject && matchesDifficulty && matchesActive;
  });

  const handleJoinRoom = (roomId: string) => {
    console.log(`Joining room: ${roomId}`);
    // Implement join room logic
  };

  const handleViewRoom = (roomId: string) => {
    console.log(`Viewing room: ${roomId}`);
    // Implement view room logic
  };

  const handleCreateRoom = () => {
    console.log("Creating new room");
    // Implement create room logic
  };

  return (
    <div className="min-h-screen bg-gradient-wellness p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-display font-bold text-foreground mb-2">
                Study Rooms
              </h1>
              <p className="text-muted-foreground">
                Join collaborative study sessions with your peers
              </p>
            </div>
            <Button
              onClick={handleCreateRoom}
              className="bg-gradient-secondary text-secondary-foreground shadow-wellness transition-smooth hover:opacity-90"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Room
            </Button>
          </div>
        </div>

        {/* Filters */}
        <Card className="mb-8 shadow-soft">
          <CardContent className="p-6">
            <div className="grid md:grid-cols-4 gap-4">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                <Input
                  placeholder="Search rooms..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 focus-ring"
                />
              </div>

              {/* Subject Filter */}
              <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                <SelectTrigger className="focus-ring">
                  <SelectValue placeholder="Subject" />
                </SelectTrigger>
                <SelectContent className="bg-popover border border-border">
                  {subjects.map((subject) => (
                    <SelectItem key={subject} value={subject} className="focus-ring">
                      {subject === "all" ? "All Subjects" : subject}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Difficulty Filter */}
              <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
                <SelectTrigger className="focus-ring">
                  <SelectValue placeholder="Difficulty" />
                </SelectTrigger>
                <SelectContent className="bg-popover border border-border">
                  {difficulties.map((difficulty) => (
                    <SelectItem key={difficulty} value={difficulty} className="focus-ring">
                      {difficulty === "all" ? "All Levels" : difficulty}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Active Filter */}
              <Button
                variant={showOnlyActive ? "default" : "outline"}
                onClick={() => setShowOnlyActive(!showOnlyActive)}
                className="transition-smooth"
              >
                <Filter className="w-4 h-4 mr-2" />
                {showOnlyActive ? "Active Only" : "All Rooms"}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center mb-3">
                <Users className="w-8 h-8 text-primary" />
              </div>
              <div className="text-2xl font-bold text-primary mb-1">
                {mockStudyRooms.filter(room => room.isActive).length}
              </div>
              <div className="text-sm text-muted-foreground">Active Rooms</div>
            </CardContent>
          </Card>

          <Card className="shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center mb-3">
                <Clock className="w-8 h-8 text-secondary" />
              </div>
              <div className="text-2xl font-bold text-secondary mb-1">
                {mockStudyRooms.reduce((total, room) => total + room.participants, 0)}
              </div>
              <div className="text-sm text-muted-foreground">Active Participants</div>
            </CardContent>
          </Card>

          <Card className="shadow-soft">
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center mb-3">
                <Badge className="bg-success text-success-foreground">
                  Online
                </Badge>
              </div>
              <div className="text-2xl font-bold text-success mb-1">
                {subjects.length - 1}
              </div>
              <div className="text-sm text-muted-foreground">Subjects Available</div>
            </CardContent>
          </Card>
        </div>

        {/* Results */}
        <div className="mb-6 flex items-center justify-between">
          <h2 className="text-xl font-display font-semibold text-foreground">
            Study Rooms ({filteredRooms.length})
          </h2>
          {filteredRooms.length === 0 && (
            <p className="text-muted-foreground">No rooms match your filters</p>
          )}
        </div>

        {/* Room Grid */}
        {filteredRooms.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredRooms.map((room) => (
              <StudyRoomCard
                key={room.id}
                {...room}
                onJoin={handleJoinRoom}
                onView={handleViewRoom}
              />
            ))}
          </div>
        ) : (
          <Card className="shadow-soft">
            <CardContent className="p-12 text-center">
              <Users className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
              <h3 className="text-lg font-medium text-foreground mb-2">
                No study rooms found
              </h3>
              <p className="text-muted-foreground mb-4">
                Try adjusting your filters or create a new study room to get started.
              </p>
              <Button
                onClick={handleCreateRoom}
                className="bg-gradient-primary text-primary-foreground shadow-focus transition-smooth"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Your First Room
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}