import { useState } from "react";
import { Users, Clock, BookOpen, Play, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface StudyRoomCardProps {
  id: string;
  title: string;
  subject: string;
  participants: number;
  maxParticipants: number;
  timeRemaining: string;
  difficulty: "Beginner" | "Intermediate" | "Advanced";
  isActive: boolean;
  tags: string[];
  hostName: string;
  onJoin?: (roomId: string) => void;
  onView?: (roomId: string) => void;
}

const difficultyColors = {
  Beginner: "bg-success text-success-foreground",
  Intermediate: "bg-warning text-warning-foreground",
  Advanced: "bg-destructive text-destructive-foreground",
};

const participantAvatars = [
  { name: "Alex", color: "bg-primary" },
  { name: "Maya", color: "bg-secondary" },
  { name: "Sam", color: "bg-accent" },
  { name: "Priya", color: "bg-success" },
];

export function StudyRoomCard({
  id,
  title,
  subject,
  participants,
  maxParticipants,
  timeRemaining,
  difficulty,
  isActive,
  tags,
  hostName,
  onJoin,
  onView,
}: StudyRoomCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  const handleJoin = () => {
    onJoin?.(id);
  };

  const handleView = () => {
    onView?.(id);
  };

  const getParticipantAvatars = () => {
    const avatarsToShow = Math.min(participants, 4);
    return participantAvatars.slice(0, avatarsToShow).map((avatar, index) => (
      <Avatar key={index} className="w-8 h-8 border-2 border-background">
        <AvatarFallback className={`${avatar.color} text-white text-xs font-medium`}>
          {avatar.name[0]}
        </AvatarFallback>
      </Avatar>
    ));
  };

  return (
    <Card
      className={`transition-all duration-300 hover:shadow-wellness hover:-translate-y-1 cursor-pointer ${
        isActive ? "ring-2 ring-primary shadow-focus" : ""
      }`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 className="font-display font-semibold text-lg text-card-foreground line-clamp-2">
              {title}
            </h3>
            <p className="text-muted-foreground text-sm mt-1">
              Hosted by {hostName}
            </p>
          </div>
          {isActive && (
            <div className="flex items-center space-x-1 text-primary animate-pulse-gentle">
              <div className="w-2 h-2 bg-primary rounded-full"></div>
              <span className="text-xs font-medium">Live</span>
            </div>
          )}
        </div>

        {/* Subject and Difficulty */}
        <div className="flex items-center justify-between mt-3">
          <div className="flex items-center space-x-2">
            <BookOpen className="w-4 h-4 text-accent" />
            <span className="text-sm font-medium text-card-foreground">
              {subject}
            </span>
          </div>
          <Badge className={`text-xs ${difficultyColors[difficulty]}`}>
            {difficulty}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="pt-0">
        {/* Tags */}
        <div className="flex flex-wrap gap-2 mb-4">
          {tags.map((tag, index) => (
            <Badge
              key={index}
              variant="outline"
              className="text-xs bg-accent-light text-accent border-accent/30"
            >
              {tag}
            </Badge>
          ))}
        </div>

        {/* Participants */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="flex -space-x-2">
              {getParticipantAvatars()}
              {participants > 4 && (
                <div className="w-8 h-8 bg-muted rounded-full border-2 border-background flex items-center justify-center">
                  <span className="text-xs font-medium text-muted-foreground">
                    +{participants - 4}
                  </span>
                </div>
              )}
            </div>
            <div className="flex items-center space-x-1 text-muted-foreground">
              <Users className="w-4 h-4" />
              <span className="text-sm">
                {participants}/{maxParticipants}
              </span>
            </div>
          </div>

          {timeRemaining && (
            <div className="flex items-center space-x-1 text-muted-foreground">
              <Clock className="w-4 h-4" />
              <span className="text-sm">{timeRemaining}</span>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex space-x-2">
          <Button
            onClick={handleJoin}
            className={`flex-1 transition-smooth ${
              isHovered
                ? "bg-gradient-primary text-primary-foreground shadow-focus"
                : "bg-primary text-primary-foreground hover:opacity-90"
            }`}
            disabled={participants >= maxParticipants}
          >
            <Play className="w-4 h-4 mr-2" />
            {participants >= maxParticipants ? "Room Full" : "Join Room"}
          </Button>

          <Button
            onClick={handleView}
            variant="outline"
            className="border-accent text-accent hover:bg-accent hover:text-accent-foreground transition-smooth"
          >
            <Eye className="w-4 h-4" />
          </Button>
        </div>

        {/* Capacity Warning */}
        {participants >= maxParticipants * 0.8 && participants < maxParticipants && (
          <div className="mt-3 p-2 bg-warning/10 border border-warning/20 rounded-md">
            <p className="text-xs text-warning font-medium">
              Almost full! Only {maxParticipants - participants} spots left.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}