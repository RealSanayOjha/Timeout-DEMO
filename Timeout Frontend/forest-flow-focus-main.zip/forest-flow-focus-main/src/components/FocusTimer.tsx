import { useState, useEffect, useRef } from "react";
import { Play, Pause, Square, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import timerIcon from "@/assets/timer-icon.jpg";

interface FocusTimerProps {
  onSessionComplete?: () => void;
}

const SESSION_TYPES = {
  pomodoro: { name: "Pomodoro", duration: 25 * 60, color: "primary" },
  deep: { name: "Deep Focus", duration: 45 * 60, color: "accent" },
  study: { name: "Study Session", duration: 60 * 60, color: "secondary" },
  break: { name: "Break Time", duration: 15 * 60, color: "success" },
};

export function FocusTimer({ onSessionComplete }: FocusTimerProps) {
  const [selectedSession, setSelectedSession] = useState<keyof typeof SESSION_TYPES>("pomodoro");
  const [timeLeft, setTimeLeft] = useState(SESSION_TYPES.pomodoro.duration);
  const [isRunning, setIsRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const currentSession = SESSION_TYPES[selectedSession];
  const totalDuration = currentSession.duration;
  const progress = ((totalDuration - timeLeft) / totalDuration) * 100;

  useEffect(() => {
    if (isRunning && !isPaused && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            setIsRunning(false);
            setIsPaused(false);
            onSessionComplete?.();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning, isPaused, timeLeft, onSessionComplete]);

  const handleStart = () => {
    setIsRunning(true);
    setIsPaused(false);
  };

  const handlePause = () => {
    setIsPaused(true);
  };

  const handleStop = () => {
    setIsRunning(false);
    setIsPaused(false);
    setTimeLeft(currentSession.duration);
  };

  const handleReset = () => {
    setIsRunning(false);
    setIsPaused(false);
    setTimeLeft(currentSession.duration);
  };

  const handleSessionChange = (session: string) => {
    const sessionKey = session as keyof typeof SESSION_TYPES;
    setSelectedSession(sessionKey);
    setTimeLeft(SESSION_TYPES[sessionKey].duration);
    setIsRunning(false);
    setIsPaused(false);
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, "0")}:${remainingSeconds
      .toString()
      .padStart(2, "0")}`;
  };

  const circumference = 2 * Math.PI * 140;
  const strokeDasharray = circumference;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  return (
    <Card className="w-full max-w-md mx-auto shadow-wellness">
      <CardContent className="p-8">
        <div className="text-center space-y-6">
          {/* Session Type Selector */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-muted-foreground">
              Session Type
            </label>
            <Select value={selectedSession} onValueChange={handleSessionChange}>
              <SelectTrigger className="focus-ring">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-popover border border-border">
                {Object.entries(SESSION_TYPES).map(([key, session]) => (
                  <SelectItem key={key} value={key} className="focus-ring">
                    {session.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Timer Display */}
          <div className="relative w-80 h-80 mx-auto">
            <svg
              className="transform -rotate-90 w-full h-full"
              viewBox="0 0 300 300"
            >
              {/* Background circle */}
              <circle
                cx="150"
                cy="150"
                r="140"
                stroke="hsl(var(--muted))"
                strokeWidth="8"
                fill="none"
                className="opacity-20"
              />
              {/* Progress circle */}
              <circle
                cx="150"
                cy="150"
                r="140"
                stroke={`hsl(var(--${currentSession.color}))`}
                strokeWidth="8"
                fill="none"
                strokeDasharray={strokeDasharray}
                strokeDashoffset={strokeDashoffset}
                className="transition-all duration-1000 ease-in-out"
                strokeLinecap="round"
              />
            </svg>
            
            {/* Timer Content */}
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <img 
                src={timerIcon} 
                alt="Timer" 
                className="w-16 h-16 mb-4 opacity-30"
              />
              <div className="text-center">
                <div className="text-4xl font-mono font-bold text-foreground mb-2">
                  {formatTime(timeLeft)}
                </div>
                <div className="text-sm text-muted-foreground">
                  {currentSession.name}
                </div>
                {isRunning && !isPaused && (
                  <div className="text-xs text-primary font-medium mt-1 animate-pulse-gentle">
                    Focus Mode Active
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Control Buttons */}
          <div className="flex justify-center space-x-3">
            {!isRunning || isPaused ? (
              <Button
                onClick={handleStart}
                className="bg-gradient-primary hover:opacity-90 text-primary-foreground px-6 py-3 shadow-focus transition-smooth"
                size="lg"
              >
                <Play className="w-5 h-5 mr-2" />
                {isPaused ? "Resume" : "Start"}
              </Button>
            ) : (
              <Button
                onClick={handlePause}
                variant="outline"
                className="border-primary text-primary hover:bg-primary hover:text-primary-foreground px-6 py-3 transition-smooth"
                size="lg"
              >
                <Pause className="w-5 h-5 mr-2" />
                Pause
              </Button>
            )}

            <Button
              onClick={handleStop}
              variant="outline"
              className="border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground transition-smooth"
              size="lg"
            >
              <Square className="w-5 h-5 mr-2" />
              Stop
            </Button>

            <Button
              onClick={handleReset}
              variant="ghost"
              className="text-muted-foreground hover:text-accent hover:bg-accent-light transition-smooth"
              size="lg"
            >
              <RotateCcw className="w-5 h-5" />
            </Button>
          </div>

          {/* Motivation Quote */}
          {isRunning && !isPaused && (
            <div className="mt-6 p-4 bg-gradient-wellness rounded-lg animate-fade-in">
              <p className="text-sm italic text-accent font-medium">
                "Focus is not about eliminating distractions, but about choosing what deserves your attention."
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}