import { useState } from "react";
import { 
  Smartphone, 
  Target, 
  Clock, 
  TrendingUp, 
  Award,
  Calendar,
  Brain,
  Zap
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";

interface WellnessStats {
  focusStreak: number;
  totalFocusTime: number;
  screenTimeReduction: number;
  studySessionsCompleted: number;
  weeklyGoal: number;
  weeklyProgress: number;
}

export function WellnessDashboard() {
  const [stats] = useState<WellnessStats>({
    focusStreak: 7,
    totalFocusTime: 1440, // minutes
    screenTimeReduction: 23, // percentage
    studySessionsCompleted: 12,
    weeklyGoal: 20,
    weeklyProgress: 65,
  });

  const achievements = [
    { name: "Focus Master", icon: Target, color: "primary", unlocked: true },
    { name: "Week Warrior", icon: Calendar, color: "secondary", unlocked: true },
    { name: "Digital Detox", icon: Smartphone, color: "accent", unlocked: false },
    { name: "Study Streak", icon: Brain, color: "success", unlocked: true },
  ];

  const formatTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}m`;
  };

  const getProgressColor = (percentage: number) => {
    if (percentage >= 80) return "bg-success";
    if (percentage >= 60) return "bg-warning";
    return "bg-primary";
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-display font-bold text-foreground">
            Digital Wellness Dashboard
          </h2>
          <p className="text-muted-foreground mt-1">
            Track your focus progress and build healthy digital habits
          </p>
        </div>
        <Button
          className="bg-gradient-secondary text-secondary-foreground shadow-wellness transition-smooth"
        >
          <Zap className="w-4 h-4 mr-2" />
          Start Focus Session
        </Button>
      </div>

      {/* Main Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Focus Streak */}
        <Card className="shadow-soft transition-smooth hover:shadow-wellness">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Focus Streak
              </CardTitle>
              <Target className="w-4 h-4 text-primary" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary mb-1">
              {stats.focusStreak} days
            </div>
            <p className="text-xs text-muted-foreground">
              Keep it going! 🔥
            </p>
          </CardContent>
        </Card>

        {/* Total Focus Time */}
        <Card className="shadow-soft transition-smooth hover:shadow-wellness">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Total Focus Time
              </CardTitle>
              <Clock className="w-4 h-4 text-secondary" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-secondary mb-1">
              {formatTime(stats.totalFocusTime)}
            </div>
            <p className="text-xs text-muted-foreground">
              This week
            </p>
          </CardContent>
        </Card>

        {/* Screen Time Reduction */}
        <Card className="shadow-soft transition-smooth hover:shadow-wellness">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Screen Time Reduced
              </CardTitle>
              <TrendingUp className="w-4 h-4 text-success" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success mb-1">
              -{stats.screenTimeReduction}%
            </div>
            <p className="text-xs text-muted-foreground">
              vs last week
            </p>
          </CardContent>
        </Card>

        {/* Study Sessions */}
        <Card className="shadow-soft transition-smooth hover:shadow-wellness">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Study Sessions
              </CardTitle>
              <Brain className="w-4 h-4 text-accent" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-accent mb-1">
              {stats.studySessionsCompleted}
            </div>
            <p className="text-xs text-muted-foreground">
              Completed today
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Weekly Progress */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="text-lg font-display">Weekly Focus Goal</CardTitle>
          <CardDescription>
            You're {stats.weeklyProgress}% towards your weekly goal of {stats.weeklyGoal} hours
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <Progress 
              value={stats.weeklyProgress} 
              className="h-3"
              style={{
                background: `hsl(var(--muted))`,
              }}
            />
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">
                {Math.round((stats.weeklyProgress / 100) * stats.weeklyGoal)}h completed
              </span>
              <span className="text-muted-foreground">
                {stats.weeklyGoal - Math.round((stats.weeklyProgress / 100) * stats.weeklyGoal)}h remaining
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Achievements */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="text-lg font-display">Achievements</CardTitle>
          <CardDescription>
            Unlock badges as you build better digital habits
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {achievements.map((achievement, index) => (
              <div
                key={index}
                className={`p-4 rounded-lg border-2 transition-smooth ${
                  achievement.unlocked
                    ? `border-${achievement.color} bg-${achievement.color}/5`
                    : "border-muted bg-muted/20"
                }`}
              >
                <div className="text-center space-y-2">
                  <achievement.icon
                    className={`w-8 h-8 mx-auto ${
                      achievement.unlocked
                        ? `text-${achievement.color}`
                        : "text-muted-foreground"
                    }`}
                  />
                  <div>
                    <p className="font-medium text-sm text-card-foreground">
                      {achievement.name}
                    </p>
                    <Badge
                      variant={achievement.unlocked ? "default" : "secondary"}
                      className="text-xs mt-1"
                    >
                      {achievement.unlocked ? "Unlocked" : "Locked"}
                    </Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Daily App Usage Heatmap */}
      <Card className="shadow-soft">
        <CardHeader>
          <CardTitle className="text-lg font-display">App Usage Patterns</CardTitle>
          <CardDescription>
            Your daily digital wellness journey (last 7 days)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2">
            {Array.from({ length: 7 }, (_, i) => {
              const usage = Math.random() * 100;
              const intensity = Math.floor(usage / 25);
              const colors = [
                "bg-muted",
                "bg-success/20",
                "bg-success/40",
                "bg-success/60",
                "bg-success",
              ];
              
              return (
                <div key={i} className="text-center">
                  <div
                    className={`w-full h-12 rounded-md ${colors[intensity]} border border-border transition-smooth hover:opacity-80 cursor-pointer`}
                    title={`Day ${7 - i}: ${Math.round(usage)}% focused`}
                  />
                  <span className="text-xs text-muted-foreground mt-1 block">
                    {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][
                      (new Date().getDay() - (6 - i) + 7) % 7
                    ]}
                  </span>
                </div>
              );
            })}
          </div>
          <div className="flex items-center justify-between mt-4 text-xs text-muted-foreground">
            <span>Less focused</span>
            <div className="flex space-x-1">
              <div className="w-3 h-3 bg-muted rounded-sm"></div>
              <div className="w-3 h-3 bg-success/20 rounded-sm"></div>
              <div className="w-3 h-3 bg-success/40 rounded-sm"></div>
              <div className="w-3 h-3 bg-success/60 rounded-sm"></div>
              <div className="w-3 h-3 bg-success rounded-sm"></div>
            </div>
            <span>More focused</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}