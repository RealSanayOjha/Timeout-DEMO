import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gradient-wellness">
        <AppSidebar />
        
        <main className="flex-1 flex flex-col">
          {/* Header */}
          <header className="h-14 flex items-center justify-between px-4 border-b border-border bg-background/80 backdrop-blur-sm">
            <div className="flex items-center space-x-4">
              <SidebarTrigger className="text-sidebar-foreground hover:bg-sidebar-accent transition-smooth" />
              <div className="hidden md:block">
                <h2 className="text-sm font-medium text-foreground">
                  {new Date().toLocaleDateString('en-IN', { 
                    weekday: 'long', 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}
                </h2>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              {/* Quick Stats */}
              <div className="hidden lg:flex items-center space-x-4 text-xs text-muted-foreground">
                <div className="flex items-center space-x-1">
                  <div className="w-2 h-2 bg-success rounded-full animate-pulse-gentle"></div>
                  <span>7 day streak</span>
                </div>
                <div className="flex items-center space-x-1">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  <span>2.5h today</span>
                </div>
              </div>

              {/* User Menu */}
              <div className="w-8 h-8 bg-gradient-primary rounded-full flex items-center justify-center cursor-pointer hover:opacity-90 transition-smooth">
                <span className="text-xs font-medium text-primary-foreground">S</span>
              </div>
            </div>
          </header>

          {/* Main Content */}
          <div className="flex-1 overflow-auto">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}